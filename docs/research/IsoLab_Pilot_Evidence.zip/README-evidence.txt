Extract into the repository root and run python scripts/pilot_publication.py.
Contains measured inputs, splits, predictions and logs; trained .keras binaries remain local and can be regenerated.
